package com.example.project_two_evann_hopkins_event_tracking_app;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class DataGridActivity extends AppCompatActivity {

    private GridView gridView;  // GridView to display events
    private List<String> eventList;  // List to store event names
    private EventAdapter eventAdapter;  // Adapter to bind event data to the GridView

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        // Initialize views and event list
        gridView = findViewById(R.id.gridViewEvents);
        eventList = new ArrayList<>();

        // Load events from the database
        loadEvents();

        // Set up the adapter for the GridView
        eventAdapter = new EventAdapter(this, eventList);
        gridView.setAdapter(eventAdapter);
    }

    // Load events from the database into the list
    private void loadEvents() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        Cursor cursor = dbHelper.getAllEvents();  // Retrieve events from the database

        if (cursor != null && cursor.moveToFirst()) {
            int eventNameColumnIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);  // Get column index

            if (eventNameColumnIndex == -1) {
                // Handle missing column
                Toast.makeText(this, "Event column not found", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add events to the list
            do {
                String eventName = cursor.getString(eventNameColumnIndex);
                eventList.add(eventName);
            } while (cursor.moveToNext());

            cursor.close();  // Close the cursor after use
        } else {
            Toast.makeText(this, "No events found", Toast.LENGTH_SHORT).show();  // Handle empty cursor
        }
    }
}