package com.example.project_two_evann_hopkins_event_tracking_app;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;  // EditText for username and password inputs
    private Button btnLogin, btnSignUp;  // Buttons for login and sign up actions

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnSignUp = findViewById(R.id.btnSignUp);

        // Handle login button click
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                // Validate login credentials
                if (validateLogin(username, password)) {
                    // If credentials are valid, navigate to DataGridActivity
                    Intent intent = new Intent(LoginActivity.this, DataGridActivity.class);
                    startActivity(intent);
                } else {
                    // Show error message if login fails
                    Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle sign-up button click
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the Sign-Up screen
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });
    }

    // Method to validate login by checking credentials from the database
    private boolean validateLogin(String username, String password) {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        Cursor cursor = dbHelper.getUser(username);

        if (cursor != null && cursor.moveToFirst()) {
            // Log all column names for debugging purposes
            String[] columnNames = cursor.getColumnNames();
            for (String columnName : columnNames) {
                Log.d("Database", "Column: " + columnName);
            }

            // Check if password matches the stored value
            int passwordColumnIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_PASSWORD);
            if (passwordColumnIndex != -1) {
                String savedPassword = cursor.getString(passwordColumnIndex);
                if (savedPassword.equals(password)) {
                    cursor.close();
                    return true;
                }
            } else {
                Log.e("Database", "Password column not found!");
            }
        }
        return false;
    }
}