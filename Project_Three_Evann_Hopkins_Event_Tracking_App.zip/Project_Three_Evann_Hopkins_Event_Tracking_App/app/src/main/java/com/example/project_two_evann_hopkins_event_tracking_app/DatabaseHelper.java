package com.example.project_two_evann_hopkins_event_tracking_app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Constants for database name and version
    private static final String DATABASE_NAME = "dataGrid.db";
    private static final int DATABASE_VERSION = 1;

    // Events table columns
    private static final String TABLE_NAME = "events";
    private static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "event_name"; // Column for event name

    // Users table columns
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username"; // Column for storing usernames
    public static final String COLUMN_PASSWORD = "password"; // Column for storing user passwords

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates tables when the database is first created
    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL query to create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);  // Execute SQL to create users table

        // SQL query to create events table
        String createEventsTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT)";
        db.execSQL(createEventsTable);  // Execute SQL to create events table
    }

    // Called when the database version changes (for upgrading the database schema)
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        // Recreate the tables with updated schema
        onCreate(db);
    }

    // Method to add an event to the database
    public long addEvent(String eventName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, eventName);
        return db.insert(TABLE_NAME, null, values);
    }

    // Method to retrieve all events from the database
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME, null, null, null, null, null, null);
    }

    // Method to delete an event by its ID
    public int deleteEvent(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // Method to update an event's name by its ID
    public int updateEvent(long id, String newEventName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, newEventName);  // Update the event name
        return db.update(TABLE_NAME, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // Method to add a user to the database
    public long addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        return db.insert(TABLE_USERS, null, values);
    }

    // Method to retrieve a user by username
    public Cursor getUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USERNAME, COLUMN_PASSWORD};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        return db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
    }

    // Method to insert a sample event into the database (for testing purposes)
    public void insertSampleEvent() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, "Sample Event");
        db.insert(TABLE_NAME, null, values);
    }
}
