package com.example.project_two_evann_hopkins_event_tracking_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class EventAdapter extends BaseAdapter {

    private Context context;  // Context for accessing resources
    private List<String> eventList;  // List holding event names

    // Constructor to initialize context and event list
    public EventAdapter(Context context, List<String> eventList) {
        this.context = context;
        this.eventList = eventList;
    }

    @Override
    public int getCount() {
        return eventList.size();  // Return the total number of events
    }

    @Override
    public Object getItem(int position) {
        return eventList.get(position);  // Return the event at the specified position
    }

    @Override
    public long getItemId(int position) {
        return position;  // Return the position as the item ID
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Inflate the layout for the grid item if it's null
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(android.R.layout.simple_list_item_1, parent, false);
        }

        // Set the event name text for the grid item
        TextView textView = convertView.findViewById(android.R.id.text1);
        textView.setText(eventList.get(position));

        return convertView;  // Return the populated view for the grid item
    }
}
