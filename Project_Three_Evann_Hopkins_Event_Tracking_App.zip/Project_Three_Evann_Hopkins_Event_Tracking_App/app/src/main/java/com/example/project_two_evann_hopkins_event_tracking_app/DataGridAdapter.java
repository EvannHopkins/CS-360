package com.example.project_two_evann_hopkins_event_tracking_app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataGridAdapter extends RecyclerView.Adapter<DataGridAdapter.DataViewHolder> {

    private final List<String> dataList;  // Data to display in the grid
    private final OnDeleteClickListener deleteClickListener;  // Listener for delete actions

    // Constructor to initialize adapter with data and listener
    public DataGridAdapter(List<String> dataList, OnDeleteClickListener deleteClickListener) {
        this.dataList = dataList;
        this.deleteClickListener = deleteClickListener;
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the row layout for each item
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_data_item, parent, false);
        return new DataViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {
        // Bind data to the views and set delete button click listener
        String data = dataList.get(position);
        holder.tvDataLabel.setText(data);
        holder.btnDelete.setOnClickListener(v -> deleteClickListener.onDeleteClick(position));
    }

    @Override
    public int getItemCount() {
        return dataList.size();  // Return the number of items in the data list
    }

    static class DataViewHolder extends RecyclerView.ViewHolder {
        TextView tvDataLabel;
        Button btnDelete;

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDataLabel = itemView.findViewById(R.id.tvDataLabel);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    // Interface to handle delete button clicks
    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }
}
