package com.example.project_two_evann_hopkins_event_tracking_app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Initialize input fields and button
        EditText phoneNumberField = findViewById(R.id.phoneNumberField);
        EditText messageField = findViewById(R.id.messageField);
        Button sendSMSButton = findViewById(R.id.sendSMSButton);

        // Set up the button to send SMS when clicked
        sendSMSButton.setOnClickListener(v -> {
            if (hasSmsPermission()) {
                // Get phone number and message from user input
                String phoneNumber = phoneNumberField.getText().toString();
                String message = messageField.getText().toString();
                // Call method to send SMS
                sendSms(phoneNumber, message);
            } else {
                // Request permission if not granted
                requestSmsPermission();
            }
        });
    }

    // Check if the app has permission to send SMS
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    // Request SMS permission if not already granted
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    // Send SMS using SmsManager
    private void sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed to Send!", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            // Check if permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show();
            } else {
                // Handle case when permission is denied
                Toast.makeText(this, "Permission Denied. SMS feature disabled.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}