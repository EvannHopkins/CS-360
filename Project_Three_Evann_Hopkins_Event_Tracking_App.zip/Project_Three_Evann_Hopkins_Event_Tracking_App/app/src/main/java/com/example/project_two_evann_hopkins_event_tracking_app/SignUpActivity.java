package com.example.project_two_evann_hopkins_event_tracking_app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class SignUpActivity extends AppCompatActivity {

    private EditText etSignUpUsername, etSignUpPassword;
    private Button btnSignUpSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Initialize views
        etSignUpUsername = findViewById(R.id.etSignUpUsername);
        etSignUpPassword = findViewById(R.id.etSignUpPassword);
        btnSignUpSubmit = findViewById(R.id.btnSignUpSubmit);

        // Handle sign-up button click
        btnSignUpSubmit.setOnClickListener(v -> {
            String username = etSignUpUsername.getText().toString().trim();
            String password = etSignUpPassword.getText().toString().trim();

            // Check if username or password is empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(SignUpActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
            // Check if password meets the minimum length requirement
            else if (password.length() < 6) {
                Toast.makeText(SignUpActivity.this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show();
            }
            else {
                // Simulate saving user details to the database
                DatabaseHelper dbHelper = new DatabaseHelper(this);
                long result = dbHelper.addUser(username, password);

                // If user is successfully added to the database
                if (result > 0) {
                    Toast.makeText(SignUpActivity.this, "Sign-Up Successful! You are logged in.", Toast.LENGTH_SHORT).show();
                    // Redirect to the EventAdapter activity
                    Intent intent = new Intent(SignUpActivity.this, EventAdapter.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(SignUpActivity.this, "Sign-Up Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to validate that the input fields are not empty
    private boolean validateInput(String username, String password) {
        return !username.isEmpty() && !password.isEmpty();
    }
}
